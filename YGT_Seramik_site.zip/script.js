const form = document.getElementById("offerForm");
const result = document.getElementById("result");

// Yayına alırken bu numarayı YGT Seramik'in WhatsApp numarasıyla değiştirin.
const WHATSAPP_NUMBER = "905000000000";

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const data = new FormData(form);
  const text =
`YGT Seramik İş Talebi
Ad Soyad: ${data.get("name")}
Telefon: ${data.get("phone")}
İl / İlçe: ${data.get("location")}
Yaklaşık m²: ${data.get("sqm") || "Belirtilmedi"}
İş Türü: ${data.get("service")}
Detay: ${data.get("details")}`;

  if (WHATSAPP_NUMBER === "905000000000") {
    result.textContent = "Form hazır. Yayına almadan önce WhatsApp numarasını eklememiz gerekiyor.";
    return;
  }

  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`, "_blank");
  result.textContent = "İş talebiniz WhatsApp üzerinden gönderilmek üzere açıldı.";
});